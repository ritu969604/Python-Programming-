import random
import string

def generate_password(length, types):
    pools = []

    if "u" in types:
        pools.append(string.ascii_uppercase)
    if "l" in types:
        pools.append(string.ascii_lowercase)
    if "n" in types:
        pools.append(string.digits)
    if "s" in types:
        pools.append(string.punctuation)

    # Guarantee at least one character from every selected type.
    password = [random.choice(pool) for pool in pools]

    all_chars = "".join(pools)
    password += [random.choice(all_chars) for _ in range(length - len(password))]

    random.shuffle(password)
    return "".join(password)

def main():
    print("===== RANDOM PASSWORD GENERATOR =====")

    while True:
        try:
            length = int(input("Enter password length (minimum 8): "))
            if length < 8:
                print("Error: Password length must be at least 8.")
                continue
        except ValueError:
            print("Error: Enter a valid integer.")
            continue

        print("\nChoose character types:")
        print("U = Uppercase")
        print("L = Lowercase")
        print("N = Numbers")
        print("S = Symbols")

        types = input("Enter choices (example: ULNS): ").lower()
        valid = set("ulns")

        if not set(types).issubset(valid) or len(set(types)) < 2:
            print("Error: Select at least 2 valid character types.")
            continue

        password = generate_password(length, set(types))
        print("\nGenerated Password:", password)

        again = input("\nGenerate another? (y/n): ").lower()
        if again != "y":
            print("Thank you!")
            break

if __name__ == "__main__":
    main()
