def get_number(prompt):
    while True:
        try:
            value = float(input(prompt))
            if value <= 0:
                print("Error: Please enter a positive value.")
            else:
                return value
        except ValueError:
            print("Error: Please enter a valid number.")

def main():
    print("===== BMI CALCULATOR =====")

    weight = get_number("Enter weight in kg: ")
    height = get_number("Enter height in meters: ")

    bmi = weight / (height ** 2)

    if bmi < 18.5:
        category = "Underweight"
    elif bmi < 25:
        category = "Normal"
    elif bmi < 30:
        category = "Overweight"
    else:
        category = "Obese"

    print("\nBMI =", round(bmi, 2))
    print("Category =", category)

if __name__ == "__main__":
    main()
