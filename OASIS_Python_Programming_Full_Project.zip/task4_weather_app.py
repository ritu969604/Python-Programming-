import requests

API_KEY = "YOUR_OPENWEATHERMAP_API_KEY"

def celsius_to_fahrenheit(celsius):
    return (celsius * 9 / 5) + 32

def main():
    print("===== BASIC WEATHER APP =====")

    if API_KEY == "YOUR_OPENWEATHERMAP_API_KEY":
        print("Please add your OpenWeatherMap API key in the API_KEY variable.")
        return

    city = input("Enter city name: ").strip()

    if not city:
        print("Error: City name cannot be empty.")
        return

    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city,
        "appid": API_KEY,
        "units": "metric"
    }

    try:
        response = requests.get(url, params=params, timeout=10)

        if response.status_code == 401:
            print("Error: Invalid API key.")
            return
        if response.status_code == 404:
            print("Error: City not found.")
            return

        response.raise_for_status()
        data = response.json()

        temp_c = data["main"]["temp"]
        temp_f = celsius_to_fahrenheit(temp_c)
        humidity = data["main"]["humidity"]
        condition = data["weather"][0]["description"]
        wind_speed = data["wind"]["speed"]

        print("\n===== WEATHER RESULT =====")
        print("City:", data["name"])
        print("Temperature:", round(temp_c, 2), "°C")
        print("Temperature:", round(temp_f, 2), "°F")
        print("Humidity:", humidity, "%")
        print("Condition:", condition.title())
        print("Wind Speed:", wind_speed, "m/s")

    except requests.exceptions.Timeout:
        print("Error: Network request timed out.")
    except requests.exceptions.RequestException as e:
        print("Error: Could not connect to the weather service.")
        print("Details:", e)
    except (KeyError, ValueError):
        print("Error: Unexpected weather data received.")

if __name__ == "__main__":
    main()
