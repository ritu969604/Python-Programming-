import socket
import threading
from datetime import datetime

HOST = "127.0.0.1"
PORT = 5000

clients = []
lock = threading.Lock()

def timestamp():
    return datetime.now().strftime("%H:%M")

def broadcast(message, sender=None):
    with lock:
        for client in clients[:]:
            if client != sender:
                try:
                    client.send(message.encode())
                except:
                    if client in clients:
                        clients.remove(client)

def handle_client(client, address):
    print("Connected:", address)
    client.send("Enter your name: ".encode())

    try:
        name = client.recv(1024).decode().strip()
        if not name:
            name = "User"

        broadcast(f"[{timestamp()}] {name} joined the chat.", client)

        while True:
            data = client.recv(1024)
            if not data:
                break

            message = data.decode().strip()
            if message.lower() == "exit":
                break

            full_message = f"[{timestamp()}] {name}: {message}"
            print(full_message)
            broadcast(full_message, client)

    except ConnectionResetError:
        pass
    finally:
        with lock:
            if client in clients:
                clients.remove(client)

        broadcast(f"[{timestamp()}] {name} disconnected.", client)
        client.close()
        print("Disconnected:", address)

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()

    print(f"Server running on {HOST}:{PORT}")

    while True:
        client, address = server.accept()
        with lock:
            clients.append(client)

        thread = threading.Thread(
            target=handle_client,
            args=(client, address),
            daemon=True
        )
        thread.start()

if __name__ == "__main__":
    main()
