import speech_recognition as sr
import pyttsx3
import datetime
import webbrowser

engine = pyttsx3.init()
recognizer = sr.Recognizer()

def speak(text):
    print("Assistant:", text)
    engine.say(text)
    engine.runAndWait()

def listen():
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=7)
            command = recognizer.recognize_google(audio).lower()
            print("You:", command)
            return command
        except (sr.UnknownValueError, sr.WaitTimeoutError):
            speak("Sorry, I could not understand. Please repeat.")
        except sr.RequestError:
            speak("Speech recognition service is unavailable.")
    return ""

def main():
    speak("Hello! I am your Python voice assistant.")
    while True:
        command = listen()

        if not command:
            continue

        if "hello" in command or "hi" in command:
            speak("Hello! How can I help you?")

        elif "time" in command:
            current_time = datetime.datetime.now().strftime("%I:%M %p")
            speak("The current time is " + current_time)

        elif "date" in command:
            current_date = datetime.datetime.now().strftime("%d %B %Y")
            speak("Today's date is " + current_date)

        elif command.startswith("search"):
            topic = command.replace("search", "", 1).strip()
            if topic:
                speak("Searching for " + topic)
                webbrowser.open(
                    "https://www.google.com/search?q=" + topic.replace(" ", "+")
                )
            else:
                speak("Please tell me what you want to search.")

        elif "exit" in command or "stop" in command or "quit" in command:
            speak("Goodbye!")
            break

        else:
            speak("I do not know that command yet.")

if __name__ == "__main__":
    main()
