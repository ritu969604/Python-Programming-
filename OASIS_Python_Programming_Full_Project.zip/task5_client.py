import socket
import threading

HOST = "127.0.0.1"
PORT = 5000

def receive_messages(client):
    while True:
        try:
            message = client.recv(1024).decode()
            if not message:
                print("\nDisconnected from server.")
                break
            print("\n" + message)
            print("> ", end="", flush=True)
        except:
            break

def main():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST, PORT))

    server_message = client.recv(1024).decode()
    print(server_message, end="")
    name = input().strip()
    client.send(name.encode())

    thread = threading.Thread(
        target=receive_messages,
        args=(client,),
        daemon=True
    )
    thread.start()

    print("Connected! Type messages below.")
    print("Type 'exit' to leave.")

    try:
        while True:
            message = input("> ")
            client.send(message.encode())

            if message.lower() == "exit":
                break
    except (KeyboardInterrupt, ConnectionResetError):
        pass
    finally:
        client.close()

if __name__ == "__main__":
    main()
