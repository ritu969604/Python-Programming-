# OASIS INFOBYTE – Python Programming

This package contains all 5 Beginner-tier Python Programming tasks from the supplied OASIS INFOBYTE Task List PDF.

## Tasks
1. Voice Assistant
2. BMI Calculator
3. Random Password Generator
4. Basic Weather App
5. Chat Application

The supplied PDF requires at least 3 of the 5 Python tasks. All 5 are included here.

## How to run
Use Python 3. Install the required packages:

```bash
pip install -r requirements.txt
```

Task 4 needs an OpenWeatherMap API key. Put your key in `task4_weather_app.py` where indicated.

Run each file with:
```bash
python task1_voice_assistant.py
python task2_bmi_calculator.py
python task3_password_generator.py
python task4_weather_app.py
python task5_server.py
python task5_client.py
```

For Task 5, start `task5_server.py` first, then open two terminals and run `task5_client.py` in both.

## Submission
Upload the project files to your GitHub repository. Add screenshots of successful outputs and a short demo video if your internship submission process asks for one.
